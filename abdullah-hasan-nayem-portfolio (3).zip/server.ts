import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import cors from "cors";
import db from "./src/db.js";
import dotenv from "dotenv";
import multer from "multer";

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || "default_secret_key_change_this";

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(process.cwd(), 'public', 'uploads');
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}_${file.originalname}`);
  }
});
const upload = multer({ storage });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());
  app.use('/uploads', express.static(path.join(process.cwd(), 'public', 'uploads')));

  // Initialize Admin User
  const anyAdmin = db.prepare("SELECT * FROM users WHERE role = ?").get("admin");
  if (!anyAdmin) {
    const adminEmail = "admin@admin.com";
    const hashedPassword = await bcrypt.hash("adminadmin", 10);
    db.prepare("INSERT INTO users (email, password, displayName, role) VALUES (?, ?, ?, ?)")
      .run(adminEmail, hashedPassword, "System Admin", "admin");
    console.log("Default admin user created: admin@admin.com / adminadmin");
  }

  // --- AUTH ROUTES ---
  app.post("/api/auth/register", async (req, res) => {
    const { email, password, displayName, role } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const stmt = db.prepare("INSERT INTO users (email, password, displayName, role) VALUES (?, ?, ?, ?)");
      const result = stmt.run(email, hashedPassword, displayName, role || 'editor');
      res.status(201).json({ id: result.lastInsertRowid, email, displayName, role });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    try {
      const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
      if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: "1d" });
      res.json({ token, user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role } });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/auth/me", (req, res) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "No token" });
    try {
      const decoded: any = jwt.verify(token, JWT_SECRET);
      const user = db.prepare("SELECT id, email, displayName, role FROM users WHERE id = ?").get(decoded.id);
      res.json(user);
    } catch (error) {
      res.status(401).json({ error: "Invalid token" });
    }
  });

  app.put("/api/auth/update-profile", async (req, res) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "No token" });
    try {
      const decoded: any = jwt.verify(token, JWT_SECRET);
      const { email, password, displayName } = req.body;
      
      let query = "UPDATE users SET ";
      const params = [];
      const updates = [];

      if (email) {
        updates.push("email = ?");
        params.push(email);
      }
      if (displayName) {
        updates.push("displayName = ?");
        params.push(displayName);
      }
      if (password) {
        const hashedPassword = await bcrypt.hash(password, 10);
        updates.push("password = ?");
        params.push(hashedPassword);
      }

      if (updates.length === 0) {
        return res.status(400).json({ error: "No fields to update" });
      }

      query += updates.join(", ") + " WHERE id = ?";
      params.push(decoded.id);

      db.prepare(query).run(...params);
      
      const updatedUser = db.prepare("SELECT id, email, displayName, role FROM users WHERE id = ?").get(decoded.id);
      res.json(updatedUser);
    } catch (error: any) {
      res.status(401).json({ error: error.message || "Invalid token" });
    }
  });

  // --- DATA ROUTES ---
  // Projects
  app.get("/api/projects", (req, res) => {
    const projects = db.prepare("SELECT * FROM projects ORDER BY createdAt DESC").all();
    res.json(projects.map((p: any) => ({ ...p, techStack: JSON.parse(p.tags || '[]') })));
  });
  app.post("/api/projects", (req, res) => {
    const { title, description, image, techStack, liveLink, githubLink, featured } = req.body;
    const stmt = db.prepare("INSERT INTO projects (title, description, image, tags, link) VALUES (?, ?, ?, ?, ?)");
    const result = stmt.run(title, description, image, JSON.stringify(techStack), liveLink);
    res.status(201).json({ id: result.lastInsertRowid, ...req.body });
  });
  app.put("/api/projects/:id", (req, res) => {
    const { title, description, image, techStack, liveLink, githubLink, featured } = req.body;
    const stmt = db.prepare("UPDATE projects SET title = ?, description = ?, image = ?, tags = ?, link = ? WHERE id = ?");
    stmt.run(title, description, image, JSON.stringify(techStack), liveLink, req.params.id);
    res.json({ id: req.params.id, ...req.body });
  });
  app.delete("/api/projects/:id", (req, res) => {
    db.prepare("DELETE FROM projects WHERE id = ?").run(req.params.id);
    res.status(204).send();
  });

  // Blogs
  app.get("/api/blogs", (req, res) => {
    const blogs = db.prepare("SELECT * FROM blogs ORDER BY createdAt DESC").all();
    res.json(blogs);
  });
  app.get("/api/blogs/:id", (req, res) => {
    const blog = db.prepare("SELECT * FROM blogs WHERE id = ?").get(req.params.id);
    res.json(blog);
  });
  app.post("/api/blogs", (req, res) => {
    const { title, content, excerpt, image, author } = req.body;
    const stmt = db.prepare("INSERT INTO blogs (title, content, excerpt, image, author) VALUES (?, ?, ?, ?, ?)");
    const result = stmt.run(title, content, excerpt, image, author);
    res.status(201).json({ id: result.lastInsertRowid, ...req.body });
  });
  app.put("/api/blogs/:id", (req, res) => {
    const { title, content, excerpt, image, author } = req.body;
    const stmt = db.prepare("UPDATE blogs SET title = ?, content = ?, excerpt = ?, image = ?, author = ? WHERE id = ?");
    stmt.run(title, content, excerpt, image, author, req.params.id);
    res.json({ id: req.params.id, ...req.body });
  });
  app.delete("/api/blogs/:id", (req, res) => {
    db.prepare("DELETE FROM blogs WHERE id = ?").run(req.params.id);
    res.status(204).send();
  });

  // Family Members
  // Migration for existing tables
  try {
    db.prepare("ALTER TABLE family_members ADD COLUMN gender TEXT").run();
    db.prepare("ALTER TABLE family_members ADD COLUMN spouse_id INTEGER").run();
  } catch (e) {
    // Columns might already exist
  }

  app.get("/api/family", (req, res) => {
    const members = db.prepare("SELECT * FROM family_members").all();
    res.json(members);
  });
  app.post("/api/family", (req, res) => {
    const { name, photo, gender, father_id, mother_id, spouse_id, birth_date, bio } = req.body;
    const stmt = db.prepare("INSERT INTO family_members (name, photo, gender, father_id, mother_id, spouse_id, birth_date, bio) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    const result = stmt.run(name, photo, gender, father_id || null, mother_id || null, spouse_id || null, birth_date, bio);
    res.status(201).json({ id: result.lastInsertRowid, ...req.body });
  });
  app.put("/api/family/:id", (req, res) => {
    const { name, photo, gender, father_id, mother_id, spouse_id, birth_date, bio } = req.body;
    const stmt = db.prepare("UPDATE family_members SET name = ?, photo = ?, gender = ?, father_id = ?, mother_id = ?, spouse_id = ?, birth_date = ?, bio = ? WHERE id = ?");
    stmt.run(name, photo, gender, father_id || null, mother_id || null, spouse_id || null, birth_date, bio, req.params.id);
    res.json({ id: req.params.id, ...req.body });
  });
  app.delete("/api/family/:id", (req, res) => {
    db.prepare("DELETE FROM family_members WHERE id = ?").run(req.params.id);
    res.status(204).send();
  });

  // Messages
  app.get("/api/messages", (req, res) => {
    const messages = db.prepare("SELECT * FROM messages ORDER BY createdAt DESC").all();
    res.json(messages);
  });
  app.post("/api/messages", (req, res) => {
    const { name, email, subject, message } = req.body;
    const stmt = db.prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
    const result = stmt.run(name, email, subject, message);
    res.status(201).json({ id: result.lastInsertRowid, ...req.body });
  });
  app.put("/api/messages/:id/read", (req, res) => {
    db.prepare("UPDATE messages SET read = 1 WHERE id = ?").run(req.params.id);
    res.json({ id: req.params.id, read: 1 });
  });
  app.delete("/api/messages/:id", (req, res) => {
    db.prepare("DELETE FROM messages WHERE id = ?").run(req.params.id);
    res.status(204).send();
  });

  // Users
  app.get("/api/users", (req, res) => {
    const users = db.prepare("SELECT id, email, displayName, role, createdAt FROM users").all();
    res.json(users);
  });
  app.put("/api/users/:id", (req, res) => {
    const { displayName, role } = req.body;
    db.prepare("UPDATE users SET displayName = ?, role = ? WHERE id = ?").run(displayName, role, req.params.id);
    res.json({ id: req.params.id, ...req.body });
  });
  app.delete("/api/users/:id", (req, res) => {
    db.prepare("DELETE FROM users WHERE id = ?").run(req.params.id);
    res.status(204).send();
  });

  // Settings
  app.get("/api/settings/:id", (req, res) => {
    const settings = db.prepare("SELECT * FROM settings WHERE id = ?").get(req.params.id) as any;
    res.json(settings ? JSON.parse(settings.data) : {});
  });
  app.post("/api/settings/:id", (req, res) => {
    const stmt = db.prepare("INSERT OR REPLACE INTO settings (id, data, updatedAt) VALUES (?, ?, CURRENT_TIMESTAMP)");
    stmt.run(req.params.id, JSON.stringify(req.body));
    res.json({ id: req.params.id, ...req.body });
  });

  app.get("/api/stats", (req, res) => {
    const projects = db.prepare("SELECT COUNT(*) as count FROM projects").get() as { count: number };
    const blogs = db.prepare("SELECT COUNT(*) as count FROM blogs").get() as { count: number };
    const family = db.prepare("SELECT COUNT(*) as count FROM family_members").get() as { count: number };
    const messages = db.prepare("SELECT COUNT(*) as count FROM messages").get() as { count: number };
    res.json({
      projects: projects.count,
      blogs: blogs.count,
      family: family.count,
      messages: messages.count
    });
  });

  // Media
  app.post("/api/media/upload", upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    const url = `/uploads/${req.file.filename}`;
    res.json({ url, name: req.file.filename });
  });
  app.get("/api/media", (req, res) => {
    const uploadPath = path.join(process.cwd(), 'public', 'uploads');
    if (!fs.existsSync(uploadPath)) return res.json([]);
    const files = fs.readdirSync(uploadPath).map(file => ({
      name: file,
      url: `/uploads/${file}`,
      type: file.match(/\.(jpg|jpeg|png|gif|webp)$/i) ? 'image' : 'file'
    }));
    res.json(files);
  });
  app.delete("/api/media/:name", (req, res) => {
    const filePath = path.join(process.cwd(), 'public', 'uploads', req.params.name);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      res.status(204).send();
    } else {
      res.status(404).json({ error: "File not found" });
    }
  });

  // --- VITE MIDDLEWARE ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
