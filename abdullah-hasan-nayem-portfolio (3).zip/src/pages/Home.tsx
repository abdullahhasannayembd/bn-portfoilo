import { motion } from 'motion/react';
import { ArrowRight, Code, Rocket, Database } from 'lucide-react';
import { Link } from 'react-router-dom';
import GlassCard from '../components/GlassCard';

export default function Home() {
  return (
    <div className="relative overflow-hidden">
      {/* Background Blobs */}
      <div className="absolute top-0 left-0 w-full h-full -z-10 overflow-hidden" aria-hidden="true">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-secondary/20 rounded-full blur-[120px] animate-pulse delay-700" />
      </div>

      {/* Hero Section */}
      <section className="min-h-[90vh] flex flex-col items-center justify-center px-6 text-center" aria-labelledby="hero-title">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="mb-6 inline-block px-4 py-1.5 rounded-full glass text-xs font-semibold tracking-widest uppercase text-primary"
        >
          নতুন সুযোগের জন্য উপলব্ধ
        </motion.div>
        
        <motion.h1
          id="hero-title"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-8xl font-black tracking-tighter text-white mb-6 leading-[0.9]"
        >
          Abdullah Hasan <br />
          <span className="text-gradient">Nayem</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="max-w-2xl text-lg md:text-xl text-slate-400 mb-10 leading-relaxed"
        >
          ফুল-স্ট্যাক ডেভেলপার, উদ্যোক্তা এবং প্রযুক্তি অনুরাগী। 
          উচ্চ-ক্ষমতাসম্পন্ন ওয়েব অ্যাপ্লিকেশন তৈরি করা এবং প্রযুক্তির ভবিষ্যৎ অন্বেষণ করা।
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6"
        >
          <Link
            to="/projects"
            className="px-8 py-4 bg-primary text-white rounded-full font-bold flex items-center justify-center space-x-2 hover:bg-blue-600 focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary transition-all hover:scale-105"
          >
            <span>প্রজেক্টসমূহ দেখুন</span>
            <ArrowRight size={20} aria-hidden="true" />
          </Link>
          <Link
            to="/contact"
            className="px-8 py-4 glass text-white rounded-full font-bold flex items-center justify-center hover:bg-white/10 focus-visible:bg-white/10 transition-all hover:scale-105"
          >
            আমার সাথে যোগাযোগ করুন
          </Link>
        </motion.div>
      </section>

      {/* Features/Stats Section */}
      <section className="max-w-7xl mx-auto px-6 py-24 grid grid-cols-1 md:grid-cols-3 gap-8" aria-label="বৈশিষ্ট্যসমূহ">
        <GlassCard className="flex flex-col items-center text-center p-10">
          <div className="p-4 bg-primary/10 rounded-2xl mb-6" aria-hidden="true">
            <Code className="text-primary" size={32} />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">আধুনিক প্রযুক্তি</h3>
          <p className="text-slate-400">
            React, Node.js এবং আধুনিক ক্লাউড ইনফ্রাস্ট্রাকচারে দক্ষতা।
          </p>
        </GlassCard>

        <GlassCard className="flex flex-col items-center text-center p-10">
          <div className="p-4 bg-secondary/10 rounded-2xl mb-6" aria-hidden="true">
            <Rocket className="text-secondary" size={32} />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">স্কেলেবল অ্যাপস</h3>
          <p className="text-slate-400">
            আপনার ব্যবসার প্রয়োজনের সাথে বৃদ্ধি পায় এমন অ্যাপ্লিকেশন তৈরি করা।
          </p>
        </GlassCard>

        <GlassCard className="flex flex-col items-center text-center p-10">
          <div className="p-4 bg-accent/10 rounded-2xl mb-6" aria-hidden="true">
            <Database className="text-accent" size={32} />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">ডেটা চালিত</h3>
          <p className="text-slate-400">
            ব্যক্তিগতকৃত এবং দক্ষ ব্যবহারকারীর অভিজ্ঞতা তৈরি করতে ডেটা ব্যবহার করা।
          </p>
        </GlassCard>
      </section>
    </div>
  );
}
