import { motion } from 'motion/react';
import GlassCard from '../components/GlassCard';

export default function About() {
  const skills = [
    { name: 'ফ্রন্টএন্ড', items: ['React', 'Next.js', 'Tailwind CSS', 'Framer Motion', 'TypeScript'] },
    { name: 'ব্যাকএন্ড', items: ['Node.js', 'Express', 'Firebase', 'PostgreSQL', 'MongoDB'] },
    { name: 'সরঞ্জাম', items: ['Git', 'Docker', 'Vite', 'Figma', 'Postman'] },
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-16"
      >
        <h2 className="text-4xl md:text-6xl font-black text-white mb-8 tracking-tighter">
          আমার <span className="text-gradient">সম্পর্কে</span>
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 text-lg text-slate-400 leading-relaxed">
            <p>
              হ্যালো! আমি আব্দুল্লাহ হাসান নায়েম, সুজানগর, পাবনার একজন আগ্রহী ডেভেলপার এবং উদ্যোক্তা, 
              বর্তমানে মাগুরা সদরে বসবাস করছি। 
              আমি কম্পিউটার সায়েন্স অ্যান্ড টেকনোলজির একজন ছাত্র, সর্বদা নতুন প্রযুক্তি শিখতে 
              এবং প্রয়োগ করতে আগ্রহী।
            </p>
            <p>
              প্রযুক্তিতে আমার যাত্রা শুরু হয়েছিল ওয়েবে কীভাবে কাজ করে তা নিয়ে কৌতূহল থেকে। 
              আজ, আমি ফুল-স্ট্যাক অ্যাপ্লিকেশন তৈরিতে বিশেষজ্ঞ যা কেবল কার্যকরী নয় বরং 
              দৃশ্যত আকর্ষণীয় এবং ব্যবহারকারী-বান্ধব।
            </p>
            <p>
              কোডিংয়ের বাইরে, আমি উদ্যোক্তা এবং কীভাবে প্রযুক্তি ব্যবহার করে বাস্তব-বিশ্বের সমস্যা 
              সমাধান করা যায় এবং সম্প্রদায়ের জন্য মূল্য তৈরি করা যায় সে বিষয়ে আগ্রহী।
            </p>
          </div>
          <GlassCard className="aspect-square flex items-center justify-center overflow-hidden">
             <img 
               src="https://picsum.photos/seed/nayem/800/800" 
               alt="আব্দুল্লাহ হাসান নায়েম - পোর্ট্রেট" 
               className="w-full h-full object-cover rounded-xl"
               referrerPolicy="no-referrer"
             />
          </GlassCard>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8" role="list">
        {skills.map((skill, idx) => (
          <motion.div
            key={skill.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            role="listitem"
          >
            <GlassCard className="h-full">
              <h3 className="text-xl font-bold text-white mb-6 border-b border-white/10 pb-4">
                {skill.name}
              </h3>
              <div className="flex flex-wrap gap-2" aria-label={`${skill.name} দক্ষতা`}>
                {skill.items.map((item) => (
                  <span 
                    key={item} 
                    className="px-3 py-1 bg-white/5 rounded-full text-sm text-slate-300 border border-white/10"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
