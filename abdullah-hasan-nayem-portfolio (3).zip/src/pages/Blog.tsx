import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { motion } from 'motion/react';
import GlassCard from '../components/GlassCard';
import { Calendar, ArrowRight } from 'lucide-react';
import { formatDate } from '../lib/utils';
import { Link } from 'react-router-dom';

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  image: string;
  author: string;
  createdAt: string;
}

export default function Blog() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const data = await api.getBlogs();
        setPosts(data);
      } catch (error) {
        console.error('Error fetching blog posts:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchPosts();
  }, []);

  if (loading) return <div className="min-h-screen flex items-center justify-center text-white">লোড হচ্ছে...</div>;

  return (
    <div className="max-w-7xl mx-auto px-6 py-24">
      <h2 className="text-4xl md:text-6xl font-black text-white mb-16 tracking-tighter">
        সাম্প্রতিক <span className="text-gradient">ব্লগ</span>
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12" role="list">
        {posts.length > 0 ? (
          posts.map((post, idx) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              role="listitem"
            >
              <GlassCard className="h-full flex flex-col md:flex-row gap-8 p-8">
                <div className="w-full md:w-1/3 aspect-square rounded-2xl overflow-hidden">
                  <img 
                    src={post.image || `https://picsum.photos/seed/${post.id}/400/400`} 
                    alt={`${post.title} ব্লগের ছবি`} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="flex-grow flex flex-col">
                  <div className="flex items-center space-x-4 text-xs font-bold uppercase tracking-widest text-primary mb-4">
                    <span>{post.author}</span>
                    <span className="w-1 h-1 bg-white/20 rounded-full" aria-hidden="true" />
                    <div className="flex items-center space-x-1 text-slate-500">
                      <Calendar size={12} aria-hidden="true" />
                      <span>{formatDate(post.createdAt)}</span>
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-4 leading-tight">{post.title}</h3>
                  <p className="text-slate-400 text-sm mb-6 line-clamp-3">{post.excerpt}</p>
                  <div className="mt-auto flex items-center justify-between">
                    <Link 
                      to={`/blog/${post.id}`}
                      className="p-3 bg-white/5 hover:bg-white/10 rounded-full transition-all text-primary focus-visible:bg-white/10"
                      aria-label={`${post.title} ব্লগটি পড়ুন`}
                    >
                      <ArrowRight size={20} aria-hidden="true" />
                    </Link>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full text-center py-20 text-slate-500" role="status">
            কোনো ব্লগ পোস্ট পাওয়া যায়নি। পরে আবার চেক করুন!
          </div>
        )}
      </div>
    </div>
  );
}
