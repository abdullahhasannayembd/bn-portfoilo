import { useState, useEffect } from 'react';
import { api } from '../services/api';
import GlassCard from '../components/GlassCard';
import { Upload, Trash2, File, Image as ImageIcon, Copy, Check } from 'lucide-react';
import { motion } from 'motion/react';

export default function AdminMedia() {
  const [files, setFiles] = useState<{ name: string; url: string; type: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  const fetchFiles = async () => {
    setLoading(true);
    try {
      const data = await api.getMedia();
      setFiles(data);
    } catch (error) {
      console.error('Error fetching files:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFiles();
  }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      await api.uploadMedia(file);
      fetchFiles();
    } catch (error) {
      console.error('Error uploading file:', error);
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (name: string) => {
    if (window.confirm('Are you sure you want to delete this file?')) {
      try {
        await api.deleteMedia(name);
        fetchFiles();
      } catch (error) {
        console.error('Error deleting file:', error);
      }
    }
  };

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopied(url);
    setTimeout(() => setCopied(null), 2000);
  };

  if (loading && files.length === 0) return <div className="text-white">Loading media...</div>;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-bold text-white">Media Manager</h3>
        <label className="px-6 py-3 bg-primary text-white rounded-xl font-bold flex items-center space-x-2 hover:bg-blue-600 transition-all cursor-pointer">
          <Upload size={20} />
          <span>{uploading ? 'Uploading...' : 'Upload File'}</span>
          <input type="file" className="hidden" onChange={handleUpload} disabled={uploading} />
        </label>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {files.map((file) => (
          <GlassCard key={file.name} className="p-4 flex flex-col">
            <div className="aspect-square rounded-xl overflow-hidden bg-white/5 mb-4 flex items-center justify-center relative group">
              {file.type === 'image' ? (
                <img src={file.url} alt={file.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <File size={48} className="text-slate-500" />
              )}
              
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-2">
                <button 
                  onClick={() => copyToClipboard(file.url)}
                  className="p-3 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-all"
                  title="Copy URL"
                >
                  {copied === file.url ? <Check size={20} className="text-green-400" /> : <Copy size={20} />}
                </button>
                <button 
                  onClick={() => handleDelete(file.name)}
                  className="p-3 bg-red-400/10 hover:bg-red-400/20 rounded-xl text-red-400 transition-all"
                  title="Delete"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
            <p className="text-xs text-slate-400 truncate font-mono">{file.name}</p>
          </GlassCard>
        ))}
        
        {files.length === 0 && !loading && (
          <div className="col-span-full text-center py-20 text-slate-500">
            No media files found. Start by uploading one!
          </div>
        )}
      </div>
    </div>
  );
}
