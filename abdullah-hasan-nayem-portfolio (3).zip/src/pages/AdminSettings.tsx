import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { auth, db } from '../firebase';
import { updateEmail, updatePassword, updateProfile as updateFirebaseProfile } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import GlassCard from '../components/GlassCard';
import { Save, Globe, Shield, Palette, Share2, Info, Code, BarChart } from 'lucide-react';
import { motion } from 'motion/react';

export default function AdminSettings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profileSaving, setProfileSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('general');
  const [profileData, setProfileData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    displayName: ''
  });
  const [formData, setFormData] = useState({
    siteTitle: 'Abdullah Hasan Nayem Portfolio',
    siteDescription: 'Professional portfolio and family tree system.',
    siteKeywords: 'developer, portfolio, family tree, react, firebase',
    logo: '',
    favicon: '',
    primaryColor: '#3b82f6',
    secondaryColor: '#6366f1',
    defaultTheme: 'dark',
    maintenanceMode: false,
    contactEmail: 'abdullahhasannayem@gmail.com',
    contactPhone: '+8801611997358',
    contactAddress: 'Magura Sadar, Bangladesh',
    footerText: '© 2026 Abdullah Hasan Nayem. All rights reserved.',
    googleAnalyticsId: '',
    headerScripts: '',
    footerScripts: '',
    blogPostsPerPage: 6,
    featuredProjectsCount: 3,
    profileName: 'Abdullah Hasan Nayem',
    profileTitle: 'Full-stack Developer & Entrepreneur',
    profileTagline: 'Building the future with modern web technologies.',
    socialLinks: {
      github: '',
      linkedin: '',
      twitter: '',
      facebook: '',
      instagram: '',
      youtube: ''
    }
  });

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const data = await api.getSettings('general');
        if (data && data.data) {
          setFormData(prev => ({ ...prev, ...data.data }));
        }
      } catch (error) {
        console.error('Error fetching settings:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
    
    if (auth.currentUser) {
      setProfileData(prev => ({
        ...prev,
        email: auth.currentUser?.email || '',
        displayName: auth.currentUser?.displayName || ''
      }));
    }
  }, []);

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;

    if (profileData.password && profileData.password !== profileData.confirmPassword) {
      alert('Passwords do not match!');
      return;
    }
    
    setProfileSaving(true);
    try {
      if (profileData.email !== auth.currentUser.email) {
        await updateEmail(auth.currentUser, profileData.email);
      }
      if (profileData.password) {
        await updatePassword(auth.currentUser, profileData.password);
      }
      if (profileData.displayName !== auth.currentUser.displayName) {
        await updateFirebaseProfile(auth.currentUser, { displayName: profileData.displayName });
      }

      // Update user document in Firestore
      await setDoc(doc(db, 'users', auth.currentUser.uid), {
        email: profileData.email,
        displayName: profileData.displayName,
        role: 'admin',
        updatedAt: new Date()
      }, { merge: true });

      alert('Profile updated successfully!');
      setProfileData(prev => ({ ...prev, password: '', confirmPassword: '' }));
    } catch (error: any) {
      console.error('Error updating profile:', error);
      alert('Failed to update profile: ' + error.message);
    } finally {
      setProfileSaving(false);
    }
  };

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.updateSettings('general', formData);
      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Failed to save settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...(prev[parent as keyof typeof prev] as any),
          [child]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
      }));
    }
  };

  if (loading) return <div className="text-white">Loading settings...</div>;

  const tabs = [
    { id: 'general', name: 'General', icon: Globe },
    { id: 'seo', name: 'SEO & Meta', icon: Info },
    { id: 'appearance', name: 'Appearance', icon: Palette },
    { id: 'social', name: 'Social Links', icon: Share2 },
    { id: 'contact', name: 'Contact Info', icon: Globe },
    { id: 'advanced', name: 'Advanced', icon: Code },
    { id: 'analytics', name: 'Analytics', icon: BarChart },
    { id: 'security', name: 'Security', icon: Shield },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap gap-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all text-sm font-bold ${
              activeTab === tab.id 
                ? 'bg-primary text-white shadow-lg shadow-primary/20' 
                : 'glass text-slate-400 hover:bg-white/5'
            }`}
          >
            <tab.icon size={16} />
            <span>{tab.name}</span>
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit}>
        <GlassCard className="p-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {activeTab === 'general' && (
              <>
                <div className="md:col-span-2">
                  <h3 className="text-xl font-bold text-white mb-6">General Site Settings</h3>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Site Title</label>
                  <input name="siteTitle" value={formData.siteTitle} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Logo URL</label>
                  <input name="logo" value={formData.logo} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Profile Name</label>
                  <input name="profileName" value={formData.profileName} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Profile Title</label>
                  <input name="profileTitle" value={formData.profileTitle} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Profile Tagline</label>
                  <textarea name="profileTagline" value={formData.profileTagline} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary resize-none" rows={2} />
                </div>
                <div className="flex items-center space-x-3">
                  <input type="checkbox" name="maintenanceMode" checked={formData.maintenanceMode} onChange={handleChange} className="w-5 h-5 rounded border-white/10 bg-white/5 text-primary" />
                  <label className="text-sm text-slate-300 font-medium">Maintenance Mode</label>
                </div>
              </>
            )}

            {activeTab === 'seo' && (
              <>
                <div className="md:col-span-2">
                  <h3 className="text-xl font-bold text-white mb-6">SEO & Metadata</h3>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Meta Description</label>
                  <textarea name="siteDescription" value={formData.siteDescription} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary resize-none" rows={3} />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Meta Keywords (comma separated)</label>
                  <input name="siteKeywords" value={formData.siteKeywords} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Favicon URL</label>
                  <input name="favicon" value={formData.favicon} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
              </>
            )}

            {activeTab === 'appearance' && (
              <>
                <div className="md:col-span-2">
                  <h3 className="text-xl font-bold text-white mb-6">Appearance & Branding</h3>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Primary Color (Hex)</label>
                  <div className="flex space-x-2">
                    <input type="color" name="primaryColor" value={formData.primaryColor} onChange={handleChange} className="w-12 h-12 rounded-xl bg-transparent border-none" />
                    <input name="primaryColor" value={formData.primaryColor} onChange={handleChange} className="flex-grow px-4 py-3 glass rounded-xl text-white" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Secondary Color (Hex)</label>
                  <div className="flex space-x-2">
                    <input type="color" name="secondaryColor" value={formData.secondaryColor} onChange={handleChange} className="w-12 h-12 rounded-xl bg-transparent border-none" />
                    <input name="secondaryColor" value={formData.secondaryColor} onChange={handleChange} className="flex-grow px-4 py-3 glass rounded-xl text-white" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Default Theme</label>
                  <select name="defaultTheme" value={formData.defaultTheme} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white bg-slate-900">
                    <option value="dark">Dark Mode</option>
                    <option value="light">Light Mode</option>
                  </select>
                </div>
              </>
            )}

            {activeTab === 'social' && (
              <>
                <div className="md:col-span-2">
                  <h3 className="text-xl font-bold text-white mb-6">Social Media Links</h3>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">GitHub</label>
                  <input name="socialLinks.github" value={formData.socialLinks.github} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">LinkedIn</label>
                  <input name="socialLinks.linkedin" value={formData.socialLinks.linkedin} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Twitter / X</label>
                  <input name="socialLinks.twitter" value={formData.socialLinks.twitter} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Facebook</label>
                  <input name="socialLinks.facebook" value={formData.socialLinks.facebook} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Instagram</label>
                  <input name="socialLinks.instagram" value={formData.socialLinks.instagram} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">YouTube</label>
                  <input name="socialLinks.youtube" value={formData.socialLinks.youtube} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
              </>
            )}

            {activeTab === 'contact' && (
              <>
                <div className="md:col-span-2">
                  <h3 className="text-xl font-bold text-white mb-6">Contact Information</h3>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Contact Email</label>
                  <input name="contactEmail" type="email" value={formData.contactEmail} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Contact Phone</label>
                  <input name="contactPhone" value={formData.contactPhone} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Contact Address</label>
                  <input name="contactAddress" value={formData.contactAddress} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Footer Copyright Text</label>
                  <input name="footerText" value={formData.footerText} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
              </>
            )}

            {activeTab === 'advanced' && (
              <>
                <div className="md:col-span-2">
                  <h3 className="text-xl font-bold text-white mb-6">Advanced Configuration</h3>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Blog Posts Per Page</label>
                  <input name="blogPostsPerPage" type="number" value={formData.blogPostsPerPage} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Featured Projects Count</label>
                  <input name="featuredProjectsCount" type="number" value={formData.featuredProjectsCount} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Custom Header Scripts</label>
                  <textarea name="headerScripts" value={formData.headerScripts} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white font-mono text-xs" rows={4} placeholder="<script>...</script>" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Custom Footer Scripts</label>
                  <textarea name="footerScripts" value={formData.footerScripts} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white font-mono text-xs" rows={4} placeholder="<script>...</script>" />
                </div>
              </>
            )}

            {activeTab === 'analytics' && (
              <>
                <div className="md:col-span-2">
                  <h3 className="text-xl font-bold text-white mb-6">Analytics & Tracking</h3>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Google Analytics ID</label>
                  <input name="googleAnalyticsId" value={formData.googleAnalyticsId} onChange={handleChange} className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" placeholder="G-XXXXXXXXXX" />
                </div>
              </>
            )}

            {activeTab === 'security' && (
              <>
                <div className="md:col-span-2">
                  <h3 className="text-xl font-bold text-white mb-6">Security Settings</h3>
                </div>
                <div className="md:col-span-2 p-6 rounded-xl bg-blue-400/5 border border-blue-400/10 mb-8">
                  <p className="text-blue-400 text-sm font-medium">Security settings are managed via the custom backend server and JWT authentication.</p>
                </div>

                <div className="md:col-span-2">
                  <h4 className="text-lg font-bold text-white mb-4">Admin Account</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Admin Email</label>
                      <input 
                        name="email" 
                        type="email" 
                        value={profileData.email} 
                        onChange={handleProfileChange} 
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" 
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Display Name</label>
                      <input 
                        name="displayName" 
                        value={profileData.displayName} 
                        onChange={handleProfileChange} 
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" 
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">New Password (leave blank to keep current)</label>
                      <input 
                        name="password" 
                        type="password" 
                        value={profileData.password} 
                        onChange={handleProfileChange} 
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" 
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Confirm New Password</label>
                      <input 
                        name="confirmPassword" 
                        type="password" 
                        value={profileData.confirmPassword} 
                        onChange={handleProfileChange} 
                        className="w-full px-4 py-3 glass rounded-xl text-white focus:ring-2 focus:ring-primary" 
                      />
                    </div>
                    <div className="md:col-span-2">
                      <button 
                        type="button"
                        onClick={handleProfileSubmit}
                        disabled={profileSaving}
                        className="px-6 py-3 bg-primary/20 text-primary border border-primary/30 font-bold rounded-xl hover:bg-primary/30 transition-all disabled:opacity-50"
                      >
                        {profileSaving ? 'Updating...' : 'Update Admin Account'}
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="mt-12 pt-8 border-t border-white/5">
            <button 
              type="submit"
              disabled={saving}
              className="px-8 py-4 bg-primary text-white font-bold rounded-xl flex items-center space-x-3 hover:bg-blue-600 transition-all disabled:opacity-50 shadow-lg shadow-primary/20"
            >
              {saving ? <span>Saving...</span> : (
                <>
                  <Save size={20} />
                  <span>Save All Settings</span>
                </>
              )}
            </button>
          </div>
        </GlassCard>
      </form>
    </div>
  );
}
