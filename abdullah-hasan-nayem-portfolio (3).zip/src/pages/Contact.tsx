import { useState } from 'react';
import { api } from '../services/api';
import { motion } from 'motion/react';
import GlassCard from '../components/GlassCard';
import { Send, Mail, Phone, MapPin } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '', subject: 'Contact Form Message' });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    try {
      await api.sendMessage(formData);
      setStatus('success');
      setFormData({ name: '', email: '', message: '', subject: 'Contact Form Message' });
    } catch (error) {
      console.error('Error sending message:', error);
      setStatus('error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-24">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <h2 className="text-4xl md:text-6xl font-black text-white mb-8 tracking-tighter">
            যোগাযোগ <span className="text-gradient">করুন</span>
          </h2>
          <p className="text-lg text-slate-400 mb-12 leading-relaxed">
            মনে কোনো প্রজেক্ট আছে বা শুধু হ্যালো বলতে চান? 
            নির্দ্বিধায় যোগাযোগ করুন। আমি সর্বদা নতুন প্রজেক্ট, 
            সৃজনশীল ধারণা বা আপনার দৃষ্টিভঙ্গির অংশ হওয়ার সুযোগ নিয়ে আলোচনা করতে আগ্রহী।
          </p>

          <div className="space-y-8">
            <div className="flex items-start space-x-6">
              <div className="p-4 glass rounded-2xl text-primary">
                <Mail size={24} />
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">ইমেইল</h4>
                <p className="text-slate-400">abdullahhasannayem@gmail.com</p>
              </div>
            </div>
            <div className="flex items-start space-x-6">
              <div className="p-4 glass rounded-2xl text-secondary">
                <Phone size={24} />
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">ফোন</h4>
                <p className="text-slate-400">+8801611997358</p>
              </div>
            </div>
            <div className="flex items-start space-x-6">
              <div className="p-4 glass rounded-2xl text-accent">
                <MapPin size={24} />
              </div>
              <div>
                <h4 className="text-white font-bold mb-1">অবস্থান</h4>
                <p className="text-slate-400">মাগুরা সদর, বাংলাদেশ</p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <GlassCard className="p-10">
            <form onSubmit={handleSubmit} className="space-y-6" aria-label="যোগাযোগ ফর্ম">
              <div>
                <label htmlFor="name" className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">নাম</label>
                <input 
                  id="name"
                  type="text" 
                  required
                  aria-required="true"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-6 py-4 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary transition-all"
                  placeholder="আপনার নাম"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">ইমেইল</label>
                <input 
                  id="email"
                  type="email" 
                  required
                  aria-required="true"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full px-6 py-4 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary transition-all"
                  placeholder="আপনার@ইমেইল.কম"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">বার্তা</label>
                <textarea 
                  id="message"
                  required
                  aria-required="true"
                  rows={5}
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  className="w-full px-6 py-4 glass rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-primary transition-all resize-none"
                  placeholder="আপনার প্রজেক্ট সম্পর্কে বলুন..."
                />
              </div>
              
              <button 
                type="submit"
                disabled={status === 'submitting'}
                className="w-full py-4 bg-primary text-white font-bold rounded-xl flex items-center justify-center space-x-3 hover:bg-blue-600 focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary transition-all disabled:opacity-50"
              >
                {status === 'submitting' ? (
                  <span>পাঠানো হচ্ছে...</span>
                ) : (
                  <>
                    <span>বার্তা পাঠান</span>
                    <Send size={20} aria-hidden="true" />
                  </>
                )}
              </button>

              <div aria-live="polite" className="text-center">
                {status === 'success' && (
                  <p className="text-green-400 font-medium">বার্তা সফলভাবে পাঠানো হয়েছে!</p>
                )}
                {status === 'error' && (
                  <p className="text-red-400 font-medium">কিছু ভুল হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।</p>
                )}
              </div>
            </form>
          </GlassCard>
        </motion.div>
      </div>
    </div>
  );
}
