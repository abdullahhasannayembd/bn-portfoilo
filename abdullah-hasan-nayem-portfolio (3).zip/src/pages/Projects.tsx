import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { motion } from 'motion/react';
import GlassCard from '../components/GlassCard';
import { ExternalLink, Github } from 'lucide-react';

interface Project {
  id: string;
  title: string;
  description: string;
  image: string;
  tags: string;
  link: string;
  createdAt: string;
}

export default function Projects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const data = await api.getProjects();
        setProjects(data);
      } catch (error) {
        console.error('Error fetching projects:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchProjects();
  }, []);

  if (loading) return <div className="min-h-screen flex items-center justify-center text-white">লোড হচ্ছে...</div>;

  return (
    <div className="max-w-7xl mx-auto px-6 py-24">
      <h2 className="text-4xl md:text-6xl font-black text-white mb-16 tracking-tighter">
        আমার <span className="text-gradient">প্রজেক্টসমূহ</span>
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" role="list">
        {projects.length > 0 ? (
          projects.map((project, idx) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1 }}
              role="listitem"
            >
              <GlassCard className="h-full flex flex-col">
                <div className="aspect-video overflow-hidden rounded-xl mb-6">
                  <img 
                    src={project.image || `https://picsum.photos/seed/${project.id}/600/400`} 
                    alt={`${project.title} প্রজেক্টের ছবি`} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{project.title}</h3>
                <p className="text-slate-400 text-sm mb-6 flex-grow">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-6" aria-label="ব্যবহৃত প্রযুক্তি">
                  {project.tags?.split(',').map(tech => (
                    <span key={tech} className="text-[10px] uppercase tracking-wider px-2 py-1 bg-primary/10 text-primary rounded-md font-bold">
                      {tech.trim()}
                    </span>
                  ))}
                </div>
                <div className="flex space-x-4">
                  {project.link && (
                    <a 
                      href={project.link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 text-sm font-bold text-white hover:text-primary focus-visible:text-primary transition-colors"
                      aria-label={`${project.title} প্রজেক্টটি নতুন ট্যাবে দেখুন`}
                    >
                      <ExternalLink size={16} aria-hidden="true" />
                      <span>প্রজেক্ট দেখুন</span>
                    </a>
                  )}
                </div>
              </GlassCard>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full text-center py-20 text-slate-500" role="status">
            কোনো প্রজেক্ট পাওয়া যায়নি। পরে আবার চেক করুন!
          </div>
        )}
      </div>
    </div>
  );
}
