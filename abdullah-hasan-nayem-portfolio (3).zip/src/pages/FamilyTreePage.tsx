import FamilyTree from '../components/FamilyTree';

export default function FamilyTreePage() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-24 min-h-screen">
      <div className="mb-12">
        <h2 className="text-4xl md:text-6xl font-black text-white mb-4 tracking-tighter">
          বংশ<span className="text-gradient">তালিকা</span>
        </h2>
        <p className="text-slate-400 max-w-2xl">
          আব্দুল্লাহ হাসান নায়েম পরিবারের শিকড় এবং সংযোগগুলি অন্বেষণ করুন। 
          D3.js দ্বারা চালিত ইন্টারেক্টিভ ভিজ্যুয়ালাইজেশন। প্রোফাইল দেখতে একজন সদস্যের উপর ক্লিক করুন।
        </p>
      </div>
      
      <div className="h-[700px]">
        <FamilyTree />
      </div>
    </div>
  );
}
