import { useState, useEffect } from 'react';
import { api } from '../services/api';
import GlassCard from '../components/GlassCard';
import { 
  Briefcase, 
  FileText, 
  Users, 
  MessageSquare, 
  Plus, 
  ExternalLink, 
  TrendingUp, 
  Activity,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Settings
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '../lib/utils';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { format } from 'date-fns';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    projects: 0,
    blogs: 0,
    family: 0,
    messages: 0
  });
  const [loading, setLoading] = useState(true);
  const [recentMessages, setRecentMessages] = useState<any[]>([]);

  const chartData = [
    { name: 'Mon', views: 400, messages: 24 },
    { name: 'Tue', views: 300, messages: 13 },
    { name: 'Wed', views: 600, messages: 98 },
    { name: 'Thu', views: 478, messages: 39 },
    { name: 'Fri', views: 189, messages: 48 },
    { name: 'Sat', views: 239, messages: 38 },
    { name: 'Sun', views: 349, messages: 43 },
  ];

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [statsData, messagesData] = await Promise.all([
          api.getStats(),
          api.getMessages()
        ]);
        setStats({
          projects: statsData.projects,
          blogs: statsData.blogs,
          family: statsData.family,
          messages: statsData.messages
        });
        setRecentMessages(messagesData.slice(0, 5));
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center h-[60vh]">
      <div className="flex flex-col items-center space-y-4">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="text-slate-500 font-bold text-sm uppercase tracking-widest">ড্যাশবোর্ড লোড হচ্ছে...</p>
      </div>
    </div>
  );

  const statCards = [
    { 
      name: 'মোট প্রজেক্ট', 
      value: stats.projects, 
      icon: Briefcase, 
      color: 'text-blue-400', 
      bg: 'bg-blue-400/10',
      trend: '+2.5%',
      up: true
    },
    { 
      name: 'ব্লগ পোস্ট', 
      value: stats.blogs, 
      icon: FileText, 
      color: 'text-purple-400', 
      bg: 'bg-purple-400/10',
      trend: '+1.2%',
      up: true
    },
    { 
      name: 'পারিবারিক নেটওয়ার্ক', 
      value: stats.family, 
      icon: Users, 
      color: 'text-green-400', 
      bg: 'bg-green-400/10',
      trend: '0%',
      up: true
    },
    { 
      name: 'নতুন বার্তা', 
      value: stats.messages, 
      icon: MessageSquare, 
      color: 'text-amber-400', 
      bg: 'bg-amber-400/10',
      trend: '-4.1%',
      up: false
    },
  ];

  return (
    <div className="space-y-8 pb-10">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat) => (
          <GlassCard key={stat.name} className="p-6 group hover:border-primary/30 transition-all duration-500">
            <div className="flex items-center justify-between mb-4">
              <div className={stat.bg + " p-3 rounded-xl " + stat.color + " group-hover:scale-110 transition-transform duration-500"}>
                <stat.icon size={20} />
              </div>
              <div className={cn(
                "flex items-center space-x-1 px-2 py-1 rounded-lg text-[10px] font-black",
                stat.up ? "text-green-400 bg-green-400/10" : "text-red-400 bg-red-400/10"
              )}>
                {stat.up ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
                <span>{stat.trend}</span>
              </div>
            </div>
            <div>
              <p className="text-slate-500 font-bold text-[10px] uppercase tracking-widest mb-1">{stat.name}</p>
              <h3 className="text-3xl font-black text-white">{stat.value}</h3>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <GlassCard className="p-8 lg:col-span-2">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
            <div>
              <h3 className="text-xl font-black text-white flex items-center space-x-2">
                <Activity size={20} className="text-primary" />
                <span>এনগেজমেন্ট ওভারভিউ</span>
              </h3>
              <p className="text-slate-500 text-xs font-medium">দৈনিক ভিজিটর ট্রাফিক এবং ইন্টারঅ্যাকশন</p>
            </div>
            <div className="flex items-center space-x-2 bg-white/5 p-1 rounded-xl">
              <button className="px-3 py-1.5 rounded-lg bg-primary text-white text-[10px] font-black uppercase">সাপ্তাহিক</button>
              <button className="px-3 py-1.5 rounded-lg text-slate-500 text-[10px] font-black uppercase hover:text-white transition-colors">মাসিক</button>
            </div>
          </div>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  stroke="#475569" 
                  fontSize={10} 
                  fontWeight={700}
                  tickLine={false} 
                  axisLine={false} 
                  dy={10}
                />
                <YAxis 
                  stroke="#475569" 
                  fontSize={10} 
                  fontWeight={700}
                  tickLine={false} 
                  axisLine={false} 
                  dx={-10}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #ffffff10', borderRadius: '16px', padding: '12px' }}
                  itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                  labelStyle={{ color: '#64748b', marginBottom: '4px', fontSize: '10px', fontWeight: 'black', textTransform: 'uppercase' }}
                  cursor={{ stroke: '#3b82f6', strokeWidth: 2, strokeDasharray: '5 5' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="views" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorViews)" 
                  animationDuration={2000}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        <div className="space-y-8">
          <GlassCard className="p-8">
            <h3 className="text-xl font-black text-white mb-6 flex items-center space-x-2">
              <Plus size={20} className="text-primary" />
              <span>দ্রুত অ্যাকশন</span>
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <Link to="/admin/projects" className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-primary/30 hover:bg-primary/5 transition-all group">
                <Briefcase size={20} className="mb-2 text-primary group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 group-hover:text-white">প্রজেক্ট</span>
              </Link>
              <Link to="/admin/blogs" className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-purple-400/30 hover:bg-purple-400/5 transition-all group">
                <FileText size={20} className="mb-2 text-purple-400 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 group-hover:text-white">ব্লগ</span>
              </Link>
              <Link to="/admin/family" className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-green-400/30 hover:bg-green-400/5 transition-all group">
                <Users size={20} className="mb-2 text-green-400 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 group-hover:text-white">সদস্য</span>
              </Link>
              <Link to="/" target="_blank" className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-slate-400/30 hover:bg-white/10 transition-all group">
                <ExternalLink size={20} className="mb-2 text-slate-400 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 group-hover:text-white">লাইভ সাইট</span>
              </Link>
            </div>
          </GlassCard>

          <GlassCard className="p-8">
            <h3 className="text-xl font-black text-white mb-6 flex items-center space-x-2">
              <Activity size={20} className="text-green-400" />
              <span>সিস্টেম স্ট্যাটাস</span>
            </h3>
            <div className="space-y-4">
              {[
                { name: 'ডেটাবেস', status: 'অনলাইন', color: 'bg-green-400' },
                { name: 'এপিআই সার্ভার', status: 'সুস্থ', color: 'bg-green-400' },
                { name: 'ফাইল স্টোরেজ', status: 'অনলাইন', color: 'bg-green-400' },
              ].map((item) => (
                <div key={item.name} className="flex justify-between items-center p-3 rounded-xl bg-white/5 border border-white/5">
                  <span className="text-slate-400 text-xs font-bold">{item.name}</span>
                  <div className="flex items-center space-x-2">
                    <div className={cn("w-1.5 h-1.5 rounded-full animate-pulse", item.color)}></div>
                    <span className={cn("text-[10px] font-black uppercase tracking-widest", item.color.replace('bg-', 'text-'))}>{item.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>
      </div>

      {/* Recent Activity & Messages */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <GlassCard className="p-8 lg:col-span-2">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xl font-black text-white flex items-center space-x-2">
              <MessageSquare size={20} className="text-amber-400" />
              <span>সাম্প্রতিক বার্তা</span>
            </h3>
            <Link to="/admin/messages" className="text-[10px] font-black uppercase tracking-widest text-primary hover:underline">সব দেখুন</Link>
          </div>
          
          <div className="space-y-4">
            {recentMessages.length > 0 ? (
              recentMessages.map((msg) => (
                <div key={msg.id} className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all flex items-start space-x-4">
                  <div className="w-10 h-10 rounded-full bg-amber-400/10 flex items-center justify-center text-amber-400 font-black text-xs shrink-0">
                    {msg.name[0].toUpperCase()}
                  </div>
                  <div className="flex-grow min-w-0">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="text-sm font-bold text-white truncate">{msg.name}</h4>
                      <span className="text-[10px] font-bold text-slate-500 whitespace-nowrap ml-2">
                        {msg.createdAt && format(
                          msg.createdAt.toDate ? msg.createdAt.toDate() : new Date(msg.createdAt), 
                          'MMM d, h:mm a'
                        )}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 truncate mb-2">{msg.subject}</p>
                    <div className="flex items-center space-x-2">
                      {msg.read ? (
                        <span className="flex items-center space-x-1 text-[10px] font-black uppercase text-green-400">
                          <CheckCircle2 size={10} />
                          <span>পড়া হয়েছে</span>
                        </span>
                      ) : (
                        <span className="flex items-center space-x-1 text-[10px] font-black uppercase text-amber-400">
                          <AlertCircle size={10} />
                          <span>নতুন</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-10">
                <p className="text-slate-500 text-sm italic">কোনো সাম্প্রতিক বার্তা পাওয়া যায়নি।</p>
              </div>
            )}
          </div>
        </GlassCard>

        <GlassCard className="p-8">
          <h3 className="text-xl font-black text-white mb-8 flex items-center space-x-2">
            <Clock size={20} className="text-purple-400" />
            <span>সাম্প্রতিক কার্যকলাপ</span>
          </h3>
          <div className="space-y-6">
            {[
              { type: 'প্রজেক্ট', action: 'নতুন প্রজেক্ট তৈরি করা হয়েছে', time: '২ ঘণ্টা আগে', icon: Briefcase, color: 'text-blue-400' },
              { type: 'ব্লগ', action: 'ব্লগ পোস্ট আপডেট করা হয়েছে', time: '৫ ঘণ্টা আগে', icon: FileText, color: 'text-purple-400' },
              { type: 'পরিবার', action: 'নতুন সদস্য যোগ করা হয়েছে', time: '১ দিন আগে', icon: Users, color: 'text-green-400' },
              { type: 'সেটিংস', action: 'সাইট এসইও আপডেট করা হয়েছে', time: '২ দিন আগে', icon: Settings, color: 'text-slate-400' },
            ].map((activity, i) => (
              <div key={i} className="flex space-x-4">
                <div className="relative">
                  <div className={cn("w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center", activity.color)}>
                    <activity.icon size={16} />
                  </div>
                  {i !== 3 && <div className="absolute top-8 left-1/2 -translate-x-1/2 w-[1px] h-6 bg-white/10"></div>}
                </div>
                <div>
                  <p className="text-xs font-bold text-white mb-0.5">{activity.action}</p>
                  <p className="text-[10px] font-medium text-slate-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}
