import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, User, LogOut, LayoutDashboard } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useAuth } from '../AuthContext';
import { cn } from '../lib/utils';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { user, role, logout } = useAuth();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'হোম', path: '/' },
    { name: 'আমার সম্পর্কে', path: '/about' },
    { name: 'প্রজেক্টসমূহ', path: '/projects' },
    { name: 'ব্লগ', path: '/blog' },
    { name: 'বংশতালিকা', path: '/family-tree' },
    { name: 'যোগাযোগ', path: '/contact' },
  ];

  const isAdmin = role === 'admin';

  return (
    <nav
      aria-label="প্রধান নেভিগেশন"
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4',
        scrolled ? 'glass-dark py-3' : 'bg-transparent'
      )}
    >
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-gradient tracking-tighter" aria-label="হোম পেজ">
          AHN.
        </Link>

        {/* Desktop Nav */}
        <ul className="hidden md:flex items-center space-x-8" role="list">
          {navLinks.map((link) => (
            <li key={link.path}>
              <Link
                to={link.path}
                className={cn(
                  'text-sm font-medium transition-colors hover:text-primary focus-visible:text-primary',
                  location.pathname === link.path ? 'text-primary underline decoration-2 underline-offset-4' : 'text-slate-300'
                )}
                aria-current={location.pathname === link.path ? 'page' : undefined}
              >
                {link.name}
              </Link>
            </li>
          ))}
          
          {user ? (
            <li className="flex items-center space-x-4 ml-4 pl-4 border-l border-white/10">
              {isAdmin && (
                <Link 
                  to="/admin" 
                  className="p-2 hover:bg-white/10 rounded-full transition-colors focus-visible:bg-white/10"
                  aria-label="এডমিন ড্যাশবোর্ড"
                >
                  <LayoutDashboard size={18} className="text-slate-300" aria-hidden="true" />
                </Link>
              )}
              <button 
                onClick={() => logout()}
                className="p-2 hover:bg-white/10 rounded-full transition-colors focus-visible:bg-white/10"
                title="লগআউট"
                aria-label="লগআউট"
              >
                <LogOut size={18} className="text-slate-300" aria-hidden="true" />
              </button>
            </li>
          ) : (
            <li>
              <Link 
                to="/admin/login" 
                className="ml-4 px-4 py-2 rounded-full glass hover:bg-white/20 transition-all text-sm font-medium focus-visible:bg-white/20"
              >
                লগইন
              </Link>
            </li>
          )}
        </ul>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white p-2 focus-visible:ring-2 focus-visible:ring-primary rounded-lg" 
          onClick={() => setIsOpen(!isOpen)}
          aria-label={isOpen ? "মেনু বন্ধ করুন" : "মেনু খুলুন"}
          aria-expanded={isOpen}
          aria-controls="mobile-menu"
        >
          {isOpen ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="mobile-menu"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden absolute top-full left-0 right-0 glass-dark p-6 flex flex-col space-y-4"
            role="menu"
          >
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={cn(
                  'text-lg font-medium focus-visible:text-primary',
                  location.pathname === link.path ? 'text-primary' : 'text-slate-300'
                )}
                role="menuitem"
                aria-current={location.pathname === link.path ? 'page' : undefined}
              >
                {link.name}
              </Link>
            ))}
            {user && isAdmin && (
              <Link 
                to="/admin" 
                onClick={() => setIsOpen(false)} 
                className="text-lg font-medium text-slate-300 focus-visible:text-primary"
                role="menuitem"
              >
                ড্যাশবোর্ড
              </Link>
            )}
            {user ? (
              <button 
                onClick={() => { logout(); setIsOpen(false); }}
                className="text-lg font-medium text-red-400 text-left focus-visible:text-red-300"
                role="menuitem"
              >
                লগআউট
              </button>
            ) : (
              <Link 
                to="/admin/login" 
                onClick={() => setIsOpen(false)} 
                className="text-lg font-medium text-primary focus-visible:text-blue-400"
                role="menuitem"
              >
                লগইন
              </Link>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
