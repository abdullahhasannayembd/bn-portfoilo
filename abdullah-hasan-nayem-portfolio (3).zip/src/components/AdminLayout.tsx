import { useState, useEffect } from 'react';
import { Navigate, Outlet, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { 
  LayoutDashboard, 
  Briefcase, 
  FileText, 
  Users, 
  MessageSquare, 
  Settings, 
  Image as ImageIcon,
  LogOut,
  ChevronRight,
  Menu,
  X,
  Bell,
  Search,
  User,
  ChevronLeft,
  ExternalLink
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminLayout() {
  const { user, role, loading, logout } = useAuth();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-slate-950 text-white">
    <div className="flex flex-col items-center space-y-4">
      <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      <p className="text-slate-400 font-medium animate-pulse">এডমিন প্যানেল শুরু হচ্ছে...</p>
    </div>
  </div>;
  
  if (!user || role !== 'admin') return <Navigate to="/admin/login" />;

  const menuGroups = [
    {
      title: 'প্রধান',
      items: [
        { name: 'ড্যাশবোর্ড', path: '/admin', icon: LayoutDashboard },
        { name: 'অ্যানালিটিক্স', path: '/admin/analytics', icon: LayoutDashboard, disabled: true },
      ]
    },
    {
      title: 'কন্টেন্ট',
      items: [
        { name: 'প্রজেক্টসমূহ', path: '/admin/projects', icon: Briefcase },
        { name: 'ব্লগ পোস্ট', path: '/admin/blogs', icon: FileText },
        { name: 'মিডিয়া লাইব্রেরি', path: '/admin/media', icon: ImageIcon },
      ]
    },
    {
      title: 'সিস্টেম',
      items: [
        { name: 'বংশতালিকা', path: '/admin/family', icon: Users },
        { name: 'ব্যবহারকারী ব্যবস্থাপনা', path: '/admin/users', icon: Users },
        { name: 'বার্তাসমূহ', path: '/admin/messages', icon: MessageSquare },
      ]
    },
    {
      title: 'কনফিগারেশন',
      items: [
        { name: 'সেটিংস', path: '/admin/settings', icon: Settings },
      ]
    }
  ];

  const allItems = menuGroups.flatMap(g => g.items);
  const activeItem = allItems.find(item => item.path === location.pathname) || { name: 'Admin' };

  return (
    <div className="min-h-screen flex bg-[#020617] text-slate-100 selection:bg-primary/30">
      {/* Desktop Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 280 : 80 }}
        className="hidden lg:flex flex-col border-r border-white/5 bg-slate-900/50 backdrop-blur-xl sticky top-0 h-screen z-50"
        aria-label="এডমিন সাইডবার"
      >
        <div className="p-6 flex items-center justify-between">
          <AnimatePresence mode="wait">
            {isSidebarOpen ? (
              <motion.div
                key="logo-full"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="flex items-center space-x-2"
              >
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center shadow-lg shadow-primary/20">
                  <span className="text-white font-black text-lg">A</span>
                </div>
                <span className="text-xl font-bold tracking-tighter text-white">AHN. <span className="text-primary">Admin</span></span>
              </motion.div>
            ) : (
              <motion.div
                key="logo-small"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center shadow-lg shadow-primary/20 mx-auto"
              >
                <span className="text-white font-black text-lg">A</span>
              </motion.div>
            )}
          </AnimatePresence>
          
          {isSidebarOpen && (
            <button 
              onClick={() => setIsSidebarOpen(false)}
              className="p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-white transition-colors focus-visible:bg-white/10"
              aria-label="সাইডবার বন্ধ করুন"
              aria-expanded="true"
            >
              <ChevronLeft size={18} aria-hidden="true" />
            </button>
          )}
        </div>

        {!isSidebarOpen && (
          <div className="px-6 mb-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="w-full p-1.5 rounded-lg hover:bg-white/5 text-slate-500 hover:text-white transition-colors flex justify-center focus-visible:bg-white/10"
              aria-label="সাইডবার খুলুন"
              aria-expanded="false"
            >
              <Menu size={18} aria-hidden="true" />
            </button>
          </div>
        )}
        
        <nav className="flex-grow px-4 py-2 space-y-6 overflow-y-auto custom-scrollbar" aria-label="এডমিন নেভিগেশন">
          {menuGroups.map((group, idx) => (
            <div key={idx} className="space-y-1">
              {isSidebarOpen && (
                <h5 className="px-4 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-2">
                  {group.title}
                </h5>
              )}
              <ul className="space-y-1" role="list">
                {group.items.map((item) => (
                  <li key={item.path}>
                    <Link
                      to={item.disabled ? '#' : item.path}
                      className={cn(
                        'flex items-center p-3 rounded-xl transition-all group relative focus-visible:ring-2 focus-visible:ring-primary',
                        location.pathname === item.path 
                          ? 'bg-primary text-white shadow-lg shadow-primary/20' 
                          : 'hover:bg-white/5 text-slate-400 hover:text-slate-200',
                        item.disabled && 'opacity-50 cursor-not-allowed'
                      )}
                      title={!isSidebarOpen ? item.name : ''}
                      aria-label={!isSidebarOpen ? item.name : undefined}
                      aria-current={location.pathname === item.path ? 'page' : undefined}
                    >
                      <div className={cn("flex items-center", isSidebarOpen ? "space-x-3" : "mx-auto")}>
                        <item.icon size={20} className={cn(location.pathname === item.path ? "text-white" : "text-slate-400 group-hover:text-primary transition-colors")} aria-hidden="true" />
                        {isSidebarOpen && <span className="font-semibold text-sm">{item.name}</span>}
                      </div>
                      
                      {isSidebarOpen && location.pathname === item.path && (
                        <motion.div 
                          layoutId="active-pill"
                          className="absolute right-2 w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]"
                        />
                      )}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="p-4 mt-auto border-t border-white/5">
          <button 
            onClick={logout}
            className={cn(
              "flex items-center p-3 rounded-xl text-red-400 hover:bg-red-400/10 transition-all font-bold text-sm w-full focus-visible:bg-red-400/10",
              !isSidebarOpen && "justify-center"
            )}
            aria-label="লগআউট"
          >
            <LogOut size={20} aria-hidden="true" />
            {isSidebarOpen && <span className="ml-3">লগআউট</span>}
          </button>
        </div>
      </motion.aside>

      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-slate-900/80 backdrop-blur-md border-b border-white/5 z-50 flex items-center justify-between px-6">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-white font-black text-lg">A</span>
          </div>
          <span className="text-lg font-bold tracking-tighter text-white">AHN. Admin</span>
        </div>
        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 rounded-lg bg-white/5 text-white focus-visible:ring-2 focus-visible:ring-primary"
          aria-label={isMobileMenuOpen ? "মেনু বন্ধ করুন" : "মেনু খুলুন"}
          aria-expanded={isMobileMenuOpen}
          aria-controls="mobile-admin-menu"
        >
          {isMobileMenuOpen ? <X size={24} aria-hidden="true" /> : <Menu size={24} aria-hidden="true" />}
        </button>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            id="mobile-admin-menu"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="lg:hidden fixed inset-0 top-16 bg-slate-950 z-40 p-6 overflow-y-auto"
            role="dialog"
            aria-modal="true"
            aria-label="মোবাইল এডমিন মেনু"
          >
            <nav className="space-y-6">
              {menuGroups.map((group, idx) => (
                <div key={idx} className="space-y-2">
                  <h5 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 px-2">
                    {group.title}
                  </h5>
                  <ul className="space-y-2" role="list">
                    {group.items.map((item) => (
                      <li key={item.path}>
                        <Link
                          to={item.disabled ? '#' : item.path}
                          className={cn(
                            'flex items-center space-x-4 p-4 rounded-2xl transition-all focus-visible:ring-2 focus-visible:ring-primary',
                            location.pathname === item.path 
                              ? 'bg-primary text-white' 
                              : 'bg-white/5 text-slate-400'
                          )}
                          aria-current={location.pathname === item.path ? 'page' : undefined}
                        >
                          <item.icon size={20} aria-hidden="true" />
                          <span className="font-bold">{item.name}</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
              <button 
                onClick={logout}
                className="w-full flex items-center space-x-4 p-4 rounded-2xl bg-red-400/10 text-red-400 font-bold focus-visible:ring-2 focus-visible:ring-red-400"
                aria-label="লগআউট"
              >
                <LogOut size={20} aria-hidden="true" />
                <span>লগআউট</span>
              </button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <div className="flex-grow flex flex-col min-w-0">
        {/* Top Header */}
        <header className="h-20 border-b border-white/5 bg-slate-950/50 backdrop-blur-md sticky top-0 z-30 px-6 lg:px-10 flex items-center justify-between">
          <div className="hidden lg:flex items-center space-x-4">
            <div className="relative group">
              <label htmlFor="admin-search" className="sr-only">খুঁজুন</label>
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-primary transition-colors" size={18} aria-hidden="true" />
              <input 
                id="admin-search"
                type="text" 
                placeholder="যেকোনো কিছু খুঁজুন..." 
                className="bg-white/5 border border-white/5 rounded-xl py-2 pl-10 pr-4 text-sm text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-primary/50 w-64 transition-all"
              />
            </div>
          </div>

          <div className="flex items-center space-x-3 lg:space-x-6 ml-auto">
            <Link 
              to="/" 
              target="_blank" 
              className="p-2 rounded-xl hover:bg-white/5 text-slate-400 hover:text-white transition-all flex items-center space-x-2 group focus-visible:bg-white/5"
              aria-label="লাইভ সাইট দেখুন"
            >
              <ExternalLink size={18} aria-hidden="true" />
              <span className="text-xs font-bold hidden sm:inline">লাইভ সাইট</span>
            </Link>
            
            <button 
              className="p-2 rounded-xl hover:bg-white/5 text-slate-400 hover:text-white transition-all relative focus-visible:bg-white/5"
              aria-label="নোটিফিকেশন"
            >
              <Bell size={18} aria-hidden="true" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full border-2 border-slate-950"></span>
            </button>

            <div className="h-8 w-[1px] bg-white/5 mx-2 hidden sm:block" aria-hidden="true"></div>

            <div className="flex items-center space-x-3 pl-2">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-black text-white leading-none mb-1">{user.displayName || 'এডমিন'}</p>
                <p className="text-[10px] uppercase tracking-widest text-primary font-bold leading-none">সুপার এডমিন</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-blue-600 p-[1px]" aria-hidden="true">
                <div className="w-full h-full rounded-[11px] bg-slate-900 flex items-center justify-center text-white font-black text-sm">
                  {user.displayName?.[0] || user.email?.[0].toUpperCase()}
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main id="admin-main" className="flex-grow p-6 lg:p-10 overflow-y-auto custom-scrollbar pt-24 lg:pt-10">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="max-w-7xl mx-auto"
          >
            <nav className="mb-10" aria-label="ব্রেডক্রাম্ব">
              <div className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">
                <Link to="/admin" className="hover:text-primary transition-colors">এডমিন</Link>
                <ChevronRight size={10} aria-hidden="true" />
                <span className="text-primary" aria-current="page">{activeItem.name}</span>
              </div>
              <h1 className="text-4xl font-black text-white tracking-tight">
                {activeItem.name}
              </h1>
            </nav>

            <Outlet />
          </motion.div>
        </main>
      </div>
    </div>
  );
}
