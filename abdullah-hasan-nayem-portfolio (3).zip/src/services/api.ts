import { 
  collection, 
  getDocs, 
  getDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  orderBy, 
  limit, 
  setDoc,
  Timestamp,
  serverTimestamp
} from 'firebase/firestore';
import { 
  ref, 
  uploadBytes, 
  getDownloadURL, 
  listAll, 
  deleteObject 
} from 'firebase/storage';
import { db, storage, auth } from '../firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export const api = {
  // Projects
  getProjects: async () => {
    const path = 'projects';
    try {
      const q = query(collection(db, path), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },
  createProject: async (data: any) => {
    const path = 'projects';
    try {
      const docRef = await addDoc(collection(db, path), {
        ...data,
        createdAt: serverTimestamp()
      });
      return { id: docRef.id, ...data };
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  },
  updateProject: async (id: string, data: any) => {
    const path = `projects/${id}`;
    try {
      const docRef = doc(db, 'projects', id);
      await updateDoc(docRef, data);
      return { id, ...data };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },
  deleteProject: async (id: string) => {
    const path = `projects/${id}`;
    try {
      await deleteDoc(doc(db, 'projects', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // Blogs
  getBlogs: async () => {
    const path = 'blogs';
    try {
      const q = query(collection(db, path), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },
  getBlog: async (id: string) => {
    const path = `blogs/${id}`;
    try {
      const docSnap = await getDoc(doc(db, 'blogs', id));
      if (!docSnap.exists()) throw new Error('Blog not found');
      return { id: docSnap.id, ...docSnap.data() } as any;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
    }
  },
  createBlog: async (data: any) => {
    const path = 'blogs';
    try {
      const docRef = await addDoc(collection(db, path), {
        ...data,
        createdAt: serverTimestamp()
      });
      return { id: docRef.id, ...data };
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  },
  updateBlog: async (id: string, data: any) => {
    const path = `blogs/${id}`;
    try {
      const docRef = doc(db, 'blogs', id);
      await updateDoc(docRef, data);
      return { id, ...data };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },
  deleteBlog: async (id: string) => {
    const path = `blogs/${id}`;
    try {
      await deleteDoc(doc(db, 'blogs', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // Family
  getFamily: async () => {
    const path = 'family_members';
    try {
      const snapshot = await getDocs(collection(db, path));
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },
  createFamilyMember: async (data: any) => {
    const path = 'family_members';
    try {
      const docRef = await addDoc(collection(db, path), data);
      return { id: docRef.id, ...data };
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  },
  updateFamilyMember: async (id: string, data: any) => {
    const path = `family_members/${id}`;
    try {
      const docRef = doc(db, 'family_members', id);
      await updateDoc(docRef, data);
      return { id, ...data };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },
  deleteFamilyMember: async (id: string) => {
    const path = `family_members/${id}`;
    try {
      await deleteDoc(doc(db, 'family_members', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // Messages
  getMessages: async () => {
    const path = 'messages';
    try {
      const q = query(collection(db, path), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },
  sendMessage: async (data: any) => {
    const path = 'messages';
    try {
      const docRef = await addDoc(collection(db, path), {
        ...data,
        read: false,
        createdAt: serverTimestamp()
      });
      return { id: docRef.id, ...data };
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  },
  markMessageRead: async (id: string) => {
    const path = `messages/${id}`;
    try {
      const docRef = doc(db, 'messages', id);
      await updateDoc(docRef, { read: true });
      return { id, read: true };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },
  deleteMessage: async (id: string) => {
    const path = `messages/${id}`;
    try {
      await deleteDoc(doc(db, 'messages', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // Users
  getUsers: async () => {
    const path = 'users';
    try {
      const snapshot = await getDocs(collection(db, path));
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },
  updateUser: async (id: string, data: any) => {
    const path = `users/${id}`;
    try {
      const docRef = doc(db, 'users', id);
      await updateDoc(docRef, data);
      return { id, ...data };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },
  deleteUser: async (id: string) => {
    const path = `users/${id}`;
    try {
      await deleteDoc(doc(db, 'users', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // Media
  getMedia: async () => {
    try {
      const listRef = ref(storage, 'media');
      const res = await listAll(listRef);
      const mediaPromises = res.items.map(async (item) => {
        const url = await getDownloadURL(item);
        return { name: item.name, url, type: item.name.match(/\.(jpg|jpeg|png|gif|webp)$/i) ? 'image' : 'file' };
      });
      return Promise.all(mediaPromises);
    } catch (error) {
      console.error('Error listing media:', error);
      throw error;
    }
  },
  uploadMedia: async (file: File) => {
    try {
      const storageRef = ref(storage, `media/${Date.now()}_${file.name}`);
      const snapshot = await uploadBytes(storageRef, file);
      const url = await getDownloadURL(snapshot.ref);
      return { name: snapshot.ref.name, url };
    } catch (error) {
      console.error('Error uploading media:', error);
      throw error;
    }
  },
  deleteMedia: async (name: string) => {
    try {
      const storageRef = ref(storage, `media/${name}`);
      await deleteObject(storageRef);
      return true;
    } catch (error) {
      console.error('Error deleting media:', error);
      throw error;
    }
  },

  // Settings
  getSettings: async (id: string) => {
    const path = `settings/${id}`;
    try {
      const docSnap = await getDoc(doc(db, 'settings', id));
      if (!docSnap.exists()) return { id, data: {} };
      return { id: docSnap.id, ...docSnap.data() };
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
    }
  },
  updateSettings: async (id: string, data: any) => {
    const path = `settings/${id}`;
    try {
      const docRef = doc(db, 'settings', id);
      await setDoc(docRef, { data, updatedAt: serverTimestamp() }, { merge: true });
      return { id, data };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // Stats
  getStats: async () => {
    try {
      const [projects, blogs, members, messages] = await Promise.all([
        getDocs(collection(db, 'projects')),
        getDocs(collection(db, 'blogs')),
        getDocs(collection(db, 'family_members')),
        getDocs(collection(db, 'messages'))
      ]);

      return {
        projects: projects.size,
        blogs: blogs.size,
        family: members.size,
        messages: messages.size,
        // Mocking chart data for now as Firestore aggregation is limited
        trafficData: [
          { name: 'Mon', value: 400 },
          { name: 'Tue', value: 300 },
          { name: 'Wed', value: 600 },
          { name: 'Thu', value: 800 },
          { name: 'Fri', value: 500 },
          { name: 'Sat', value: 900 },
          { name: 'Sun', value: 700 },
        ],
        messageVolume: [
          { name: 'Week 1', value: 20 },
          { name: 'Week 2', value: 45 },
          { name: 'Week 3', value: 30 },
          { name: 'Week 4', value: 55 },
        ]
      };
    } catch (error) {
      console.error('Error fetching stats:', error);
      throw error;
    }
  },

  // Auth helper
  me: async () => {
    if (!auth.currentUser) throw new Error('Not authenticated');
    const docSnap = await getDoc(doc(db, 'users', auth.currentUser.uid));
    if (!docSnap.exists()) throw new Error('User data not found');
    return { id: docSnap.id, ...docSnap.data() } as any;
  },

  register: async (data: any) => {
    const { email, password, displayName, role } = data;
    const { createUserWithEmailAndPassword, updateProfile } = await import('firebase/auth');
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    await updateProfile(user, { displayName });
    
    await setDoc(doc(db, 'users', user.uid), {
      email,
      displayName,
      role: role || 'editor',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    
    return { id: user.uid, email, displayName, role };
  },

  updateProfile: async (data: any) => {
    if (!auth.currentUser) throw new Error('Not authenticated');
    const { updateEmail, updatePassword, updateProfile } = await import('firebase/auth');
    
    if (data.email && data.email !== auth.currentUser.email) {
      await updateEmail(auth.currentUser, data.email);
    }
    if (data.password) {
      await updatePassword(auth.currentUser, data.password);
    }
    if (data.displayName) {
      await updateProfile(auth.currentUser, { displayName: data.displayName });
    }

    await updateDoc(doc(db, 'users', auth.currentUser.uid), {
      ...data,
      updatedAt: serverTimestamp()
    });
  }
};
